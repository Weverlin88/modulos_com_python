nome = 'Weverlin'

mensagem = f'''
    Olá, meu nome é {nome}.
Estou aprendendo python.'''

print(mensagem)
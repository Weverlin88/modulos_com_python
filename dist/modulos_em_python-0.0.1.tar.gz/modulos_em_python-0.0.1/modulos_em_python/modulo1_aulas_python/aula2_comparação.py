saldo = 500
saque = 250

print (saldo > saque)
print (saldo < saque)